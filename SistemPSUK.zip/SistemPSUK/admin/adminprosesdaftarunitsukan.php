<?php
include '..\config.php';

$idunit = $_POST['idunit'];
$namaunit = $_POST['namaunit'];
$setahli = $_POST['setahli'];

$query = "insert into unitsukan(IdUnit,NamaUnit,SetAhli) 
values ('$idunit','$namaunit','$setahli')";

if(mysqli_query($conn,$query)){
    echo "Berjaya";
    header("location: unitsukan.php");
}else{
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}