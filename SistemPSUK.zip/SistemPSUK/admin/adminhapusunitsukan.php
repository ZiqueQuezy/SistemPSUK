<?php
include '..\config.php';

$sql = "DELETE FROM unitsukan WHERE IdUnit='" . $_GET["IdUnit"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
    header('location:unitsukan.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>