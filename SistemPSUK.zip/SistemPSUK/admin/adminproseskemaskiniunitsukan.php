<?php
include '..\config.php';

$idunit = $_POST['idunit'];
$namaunit = $_POST['namaunit'];
$setahli = $_POST['setahli'];

$update = "UPDATE unitsukan SET IdUnit = '$idunit', NamaUnit = '$namaunit', SetAhli = '$setahli'
WHERE IdUnit = '$idunit'";

$query = mysqli_query($conn,$update);

if($query){
    header("location:unitsukan.php");
}

else{
    echo "Gagal";
}