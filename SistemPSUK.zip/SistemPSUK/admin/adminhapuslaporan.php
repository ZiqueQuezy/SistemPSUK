<?php
include '..\config.php';

$IDLaporan = $_GET['IdLaporan'];
$sql = "DELETE FROM laporan WHERE IdLaporan='$IDLaporan'";
$query = mysqli_query($conn,$sql);
if ($query) {
    echo "Record deleted successfully";
    header('location:laporan.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
?>