<?php
include '..\config.php';

$ic = $_POST['ic'];
$nama = $_POST['nama'];
$notel = $_POST['notel'];
$email = $_POST['email'];
$unitsukan = $_POST['unitsukan'];

$query1 = "insert into guru(IC,Nama,NoTel,Email,UnitSukan) 
values ('$ic','$nama','$notel','$email','$unitsukan')";

if (mysqli_query($conn, $query1)) {
    echo "Berjaya";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$query2 = "insert into usermasterlogin(IC,Password,Usertype) 
values ('$ic','GuruKVSA','Guru')";

if (mysqli_query($conn, $query2)) {
    echo "Berjaya";
    header("location: senaraiguru.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
