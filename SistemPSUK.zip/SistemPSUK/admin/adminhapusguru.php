<?php
include '..\config.php';

$sql1 = "DELETE FROM guru WHERE IC='" . $_GET["IC"] . "'";
if (mysqli_query($conn, $sql1)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}

$sql2 = "DELETE FROM usermasterlogin WHERE IC='" . $_GET["IC"] . "'";
if (mysqli_query($conn, $sql2)) {
    echo "Record deleted successfully";
    header('location:senaraiguru.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
