<!doctype html>
<html lang="en" class="h-100">
<?php
include "..\config.php";
include 'checksession.php';
$username = $_SESSION['idadmin']; //ambil id untuk pass value

if (isset($_POST['search'])) {
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `unitsukan` WHERE CONCAT (`IdUnit`, `NamaUnit`, `SetAhli`) LIKE '%" . $valueToSearch . "%'";
    $search_result = filterTable($query);
} else {
    $query = "SELECT * FROM `unitsukan`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "psuk");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.108.0">
    <title>Sistem PSUK</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/cover/">

    <link href="../asset/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        .b-example-divider {
            height: 3rem;
            background-color: rgba(0, 0, 0, .1);
            border: solid rgba(0, 0, 0, .15);
            border-width: 1px 0;
            box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
        }

        .b-example-vr {
            flex-shrink: 0;
            width: 1.5rem;
            height: 100vh;
        }

        .bi {
            vertical-align: -.125em;
            fill: currentColor;
        }

        .nav-scroller {
            position: relative;
            z-index: 2;
            height: 2.75rem;
            overflow-y: hidden;
        }

        .nav-scroller .nav {
            display: flex;
            flex-wrap: nowrap;
            padding-bottom: 1rem;
            margin-top: -1px;
            overflow-x: auto;
            text-align: center;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="../asset/dist/css/navbar.css" rel="stylesheet">
</head>

<body class="h-100 text-center text-bg-light">
    <header>
        <nav class="navbar navbar-expand-lg bg-dark-subtle" aria-label="Thirteenth navbar example">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample11" aria-controls="navbarsExample11" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse d-lg-flex" id="navbarsExample11">
                    <a class="navbar-brand col-lg-3 me-0" href="indexadmin.php"><img src="../img/kvlogo.png" width="50%"></a>
                    <ul class="navbar-nav col-lg-6 justify-content-lg-center">
                        <li class="nav-item">
                            <a class="nav-link" href="indexadmin.php">UTAMA</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="senaraiguru.php">GURU</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="senaraipelajar.php">PELAJAR</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="unitsukan.php">UNIT SUKAN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="laporan.php">LAPORAN</a>
                        </li>
                    </ul>
                    <div class="d-lg-flex col-lg-3 justify-content-lg-end">
                        <button class="btn btn-primary" onclick="location.href='logoutadmin.php';">Log Out</button>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- navbar -->
    <div class="container-lg d-flex justify-content-center align-items-center mt-5">
        <main>
            <form method="POST">
                <h2>
                    <p align="center">SENARAI UNIT SUKAN</p>
                </h2>
                <div class="float-start mt-4 mb-4" style="width: 250px;">
                    <input class="form-control" type="text" name="valueToSearch" placeholder="Carian">
                </div>
                <div class="float-start mt-4 mb-4">
                    <input class="btn btn-primary" type="submit" name="search" value="Search">
                </div>
                <div class="float-end mt-4 mb-4">
                    <a href="admindaftarunitsukan.php" class="btn btn-primary">DAFTAR UNIT SUKAN</a>
                </div>
                <table class="table table-bordered table-striped">
                    <tr>
                        <th>ID UNIT</th>
                        <th>NAMA UNIT</th>
                        <th>JUMLAH AHLI</th>
                        <th>EDIT</th>
                    </tr>
                    <?php while ($data = mysqli_fetch_array($search_result)) : ?>
                        <tr>
                            <td><?php echo strtoupper($data['IdUnit']); ?></td>
                            <td><?php echo $data['NamaUnit']; ?></td>
                            <td><?php echo $data['SetAhli']; ?></td>
                            <td><a class='btn btn-outline-warning m-1' href="adminkemaskiniunitsukan.php?IdUnit=<?php echo $data["IdUnit"]; ?>">Kemaskini</a>
                                <a class='btn btn-danger m-1' href="adminhapusunitsukan.php?IdUnit=<?php echo $data["IdUnit"]; ?>">Hapus</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            </form>
        </main>
    </div>
    </div>
</body>

</html>