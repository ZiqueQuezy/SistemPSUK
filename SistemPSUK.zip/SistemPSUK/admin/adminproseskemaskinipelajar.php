<?php
include '..\config.php';

$ic = $_POST['ic'];
$nama = $_POST['nama'];
$jantina = $_POST['jantina'];
$kelas = $_POST['kelas'];

$update1 = "UPDATE pelajar SET Nama = '$nama', Jantina = '$jantina' , Kelas = '$kelas'
WHERE IC = '$ic'";
$query = mysqli_query($conn, $update1);

if ($query) {
    header("location:senaraipelajar.php");
} else {
    echo "Gagal";
}
