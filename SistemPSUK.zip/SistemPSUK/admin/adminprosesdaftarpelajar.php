<?php
include '..\config.php';

$ic = $_POST['ic'];
$nama = $_POST['nama'];
$jantina = $_POST['jantina'];
$kelas = $_POST['kelas'];

$query1 = "insert into pelajar(IC,Nama,Jantina,Kelas) 
values ('$ic','$nama','$jantina','$kelas')";

if(mysqli_query($conn,$query1)){
    echo "Berjaya";
}else{
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$query2 ="insert into usermasterlogin(IC,Password,Usertype) 
values ('$ic','PelajarKVSA','Pelajar')";

if(mysqli_query($conn,$query2)){
    echo "Berjaya";
    header("location: senaraipelajar.php");
}else{
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}