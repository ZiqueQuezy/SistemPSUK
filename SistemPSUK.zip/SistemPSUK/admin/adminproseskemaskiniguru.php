<?php
include '..\config.php';

$ic = $_POST['ic'];
$nama = $_POST['nama'];
$notel = $_POST['notel'];
$email = $_POST['email'];
$unitsukan = $_POST['unitsukan'];

$update1 = "UPDATE guru SET  Nama = '$nama', NoTel = '$notel' , Email = '$email' , UnitSukan = '$unitsukan'
WHERE IC = '$ic'";
$query = mysqli_query($conn, $update1);

if ($query) {
    header("location:senaraiguru.php");
} else {
    echo "Gagal";
}
