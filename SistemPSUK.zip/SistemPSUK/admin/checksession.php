<!DOCTYPE html>
<html>

<head>
    <?php
    //page ini untuk semak session apabila user log masuk

    session_start();
    //semak user adakah user sama dengan list user dalam pangkalan data
    //jika bukan user,arahkan user log masuk semula 
    if (!isset($_SESSION['idadmin'])) {
        echo header("location:loginadmin.php");
        //exit ini akan putuskan talian dengan current page.
        exit(0);
    }
    ?>
</head>

<body>
</body>

</html>