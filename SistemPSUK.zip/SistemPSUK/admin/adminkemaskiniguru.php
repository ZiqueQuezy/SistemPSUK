<!DOCTYPE html>
<html>
<?php
include "..\config.php";
include 'checksession.php';
$username = $_SESSION['idadmin'];

$noic = $_GET['IC'];
$sql = "SELECT * FROM guru WHERE IC = '$noic'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($query);
?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.108.0">
  <title>Sistem PSUK</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/cover/">

  <link href="../asset/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    .b-example-divider {
      height: 3rem;
      background-color: rgba(0, 0, 0, .1);
      border: solid rgba(0, 0, 0, .15);
      border-width: 1px 0;
      box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
    }

    .b-example-vr {
      flex-shrink: 0;
      width: 1.5rem;
      height: 100vh;
    }

    .bi {
      vertical-align: -.125em;
      fill: currentColor;
    }

    .nav-scroller {
      position: relative;
      z-index: 2;
      height: 2.75rem;
      overflow-y: hidden;
    }

    .nav-scroller .nav {
      display: flex;
      flex-wrap: nowrap;
      padding-bottom: 1rem;
      margin-top: -1px;
      overflow-x: auto;
      text-align: center;
      white-space: nowrap;
      -webkit-overflow-scrolling: touch;
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="../asset/dist/css/navbar.css" rel="stylesheet">
</head>

<body class="h-100 text-center text-bg-light">
  <header>
    <nav class="navbar navbar-expand-lg bg-dark-subtle" aria-label="Thirteenth navbar example">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample11" aria-controls="navbarsExample11" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse d-lg-flex" id="navbarsExample11">
          <a class="navbar-brand col-lg-3 me-0" href="indexadmin.php"><img src="../img/kvlogo.png" width="50%"></a>
          <ul class="navbar-nav col-lg-6 justify-content-lg-center">
            <li class="nav-item">
              <a class="nav-link" href="indexadmin.php">UTAMA</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="senaraiguru.php">GURU</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="senaraipelajar.php">PELAJAR</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="unitsukan.php">UNIT SUKAN</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="laporan.php">LAPORAN</a>
            </li>
          </ul>
          <div class="d-lg-flex col-lg-3 justify-content-lg-end">
            <button class="btn btn-primary" onclick="location.href='logoutadmin.php';">Log Out</button>
          </div>
        </div>
      </div>
    </nav>
  </header>
  <!-- navbar -->
  <div class="container-lg d-flex justify-content-center align-items-center mt-5">
    <main>
      <form method="POST" action="adminproseskemaskiniguru.php">
        <h2>
          <p align="center">KEMASKINI GURU</p>
        </h2>
        <div class="form-floating mb-3">
          <input type="text" class="form-control" id="floatingInput" name="ic" maxlength="12" value="<?php echo $row['IC'];  ?>" readonly>
          <label for="floatingInput">IC</label>
        </div>
        <div class="form-floating mb-3">
          <input type="text" class="form-control" id="floatingInput" name="nama" value="<?php echo $row['Nama'];  ?>">
          <label for="floatingInput">Nama</label>
        </div>
        <div class="form-floating mb-3">
          <input type="text" class="form-control" id="floatingInput" name="notel" maxlength="12" value="<?php echo $row['NoTel'];  ?>">
          <label for="floatingInput">No.Telefon</label>
        </div>
        <div class="form-floating mb-3">
          <input type="email" class="form-control" id="floatingInput" name="email" value="<?php echo $row['Email'];  ?>">
          <label for="floatingInput">Email</label>
        </div>
        <div class="form-floating mb-3">
          <input type="text" class="form-control" id="floatingInput" name="unitsukan" value="<?php echo $row['UnitSukan'];  ?>">
          <label for="floatingInput">Unit Sukan</label>
        </div>
        <div class="float-end mt-4 mb-4">
          <button type="submit" class="btn btn-outline-primary" name="submit">KEMASKINI GURU</button>
        </div>
        <div class="float-start mt-4 mb-4">
          <button type="reset" class="btn btn-outline-danger" name="reset">RESET</button>
        </div>
      </form>
</body>

</html>