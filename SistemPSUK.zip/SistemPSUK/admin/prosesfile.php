<?php
include '..\config.php';

if(isset($_POST["submitfile"])){
    $filename = $_FILES["filename"]["tmp_name"];

    if($_FILES["filename"]["size"] > 0){
         $file_open = fopen($filename,"r");

while(($csv = fgetcsv($file_open, 100000, ",")) !== false)
{
$ic = $csv[0];
$nama = $csv[1];
$jantina = $csv[2];
$kelas = $csv[3];

    $sql1 = "INSERT INTO pelajar VALUES ('$ic','$nama','$jantina','$kelas','')";
    $sql2 = "INSERT INTO usermasterlogin VALUES ('$ic','PelajarKVSA','Pelajar')";
        $query1 = mysqli_query($conn,$sql1);
        $query2 = mysqli_query($conn,$sql2);
            }
                fclose($file_open);
                echo "CSV file import berjaya";
                header('location: senaraipelajar.php');
        }
            else
            echo "Gagal / Sila upload file CSV";
    }
?>