<?php
session_start();
include "..\config.php";

if (isset($_POST['idadmin']) && isset($_POST['password'])) {

    function validate($data)
    {

        $data = trim($data);

        $data = stripslashes($data);

        $data = htmlspecialchars($data);

        return $data;
    }

    $idadmin = validate($_POST['idadmin']);
    $password = validate($_POST['password']);
    $error = "Incorrect Id or Password";

    if (empty($idadmin)) {

        header("Location: loginadmin.php?error=ID is required");
    } else if (empty($password)) {

        header("Location: loginadmin.php?error=Password is required");
    } else {
        $sql = "SELECT * FROM adminmasterlogin WHERE IdAdmin='$idadmin' AND password='$password'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['IdAdmin'] === $idadmin && $row['Password'] === $password) {

                $_SESSION['idadmin'] = $row['IdAdmin'];

                header("Location: indexadmin.php");
            } else {
                header("Location: loginadmin.php?error=ID or Password is incorrect ");
            }
        } else {
            header("Location: loginadmin.php?error=ID or Password is incorrect ");
        }
    }
} else {

    header("Location: loginadmin.php");

    exit();
}
